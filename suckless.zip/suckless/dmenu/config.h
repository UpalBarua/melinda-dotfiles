static int topbar = 1;
static const int user_bh = 15;
static unsigned int lines = 0;
static const char worddelimiters[] = " ";
static const char *prompt = NULL;

static const char *fonts[] = {
    "FantasqueSansM Nerd Font:size=12:antialias=true:hinting=true",
    "JetBrainsMono Nerd Font:size=12:antialias=true:hinting=true"
    "ttf-joypixels:size=12:antialias=true:hinting=true"};

static const char *colors[SchemeLast][2] = {
    /*     fg         bg       */
    [SchemeNorm] = {"#c0caf5", "#24283b"},
    [SchemeSel] = {"#24283b", "#7aa2f7"},
    [SchemeOut] = {"#000000", "#00ffff"},
};
