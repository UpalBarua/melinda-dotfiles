/* appearance */
static const unsigned int borderpx = 2;
static const unsigned int gappx = 5;
static const unsigned int snap = 32;
static const int showbar = 1;
static const int topbar = 1;
static const int horizpadbar = 10;
static const int vertpadbar = 20;
static const char *fonts[] = {
    "FantasqueSansM Nerd Font:size=12:antialias=true:hinting=true"
    "JetBrainsMonoNerdFont:size=14:antialias=true:autohint=true",
    "icomoon\\-feather:size=12:antialias=true:autohint=true",
    "JoyPixels:size=14:antialias=true:autohint=true",
};
static const char col_1[] = "#1a1b26";
static const char col_2[] = "#c0caf5";
static const char col_3[] = "#565f89";
static const char col_4[] = "#7aa2f7";
static const char *colors[][3] = {
    /*               fg         bg         border   */
    [SchemeNorm] = {col_2, col_1, col_3},
    [SchemeSel] = {col_1, col_4, col_4},
};

/* tagging */
// static const char *tags[] = {
//     "", "", "", "", "",
// };

static const char *tags[] = {"1", "2", "3", "4", "5"};

static const Rule rules[] = {
    /* class      instance    title       tags mask     isfloating   monitor */
    {"Gimp", NULL, NULL, 0, 1, -1},
    {"Firefox", NULL, NULL, 1 << 8, 0, -1},
    {"Brave-browser-nightly", NULL, NULL, 2, 0, -1},
    {"VSCodium", NULL, NULL, 1, 0, -1},
    {"obsidian", NULL, NULL, 4, 0, -1},
};

/* layout(s) */
static const float mfact = 0.5;
static const int nmaster = 1;
static const int resizehints = 0;
static const int lockfullscreen = 1;

static const Layout layouts[] = {
    /* symbol     arrange function */
    {"", tile},
    {"", monocle},
    {"", NULL},
};

/* key definitions */
#define MODKEY Mod4Mask

#define TAGKEYS(KEY, TAG)                                                      \
  &((Keychord){1, {{MODKEY, KEY}}, view, {.ui = 1 << TAG}}),                   \
      &((Keychord){                                                            \
          1, {{MODKEY | ControlMask, KEY}}, toggleview, {.ui = 1 << TAG}}),    \
      &((Keychord){1, {{MODKEY | ShiftMask, KEY}}, tag, {.ui = 1 << TAG}}),    \
      &((Keychord){1,                                                          \
                   {{MODKEY | ControlMask | ShiftMask, KEY}},                  \
                   toggletag,                                                  \
                   {.ui = 1 << TAG}}),

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define SHCMD(cmd)                                                             \
  {                                                                            \
    .v = (const char *[]) { "/bin/sh", "-c", cmd, NULL }                       \
  }

/* commands */
static char dmenumon[2] = "0";
static const char *dmenucmd[] = {"dmenu_run", "-l", "10", "-p", "", NULL};
static const char *termcmd[] = {"kitty", NULL};

static Keychord *keychords[] = {
    /* Keys        function        argument */
    &((Keychord){1, {{MODKEY, XK_Return}}, spawn, {.v = termcmd}}),
    &((Keychord){1, {{MODKEY, XK_p}}, spawn, {.v = dmenucmd}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_b}}, togglebar, {0}}),
    &((Keychord){1, {{MODKEY, XK_j}}, focusstack, {.i = +1}}),
    &((Keychord){1, {{MODKEY, XK_k}}, focusstack, {.i = -1}}),
    &((Keychord){1, {{MODKEY, XK_i}}, incnmaster, {.i = +1}}),
    &((Keychord){1, {{MODKEY, XK_d}}, incnmaster, {.i = -1}}),
    &((Keychord){1, {{MODKEY, XK_h}}, setmfact, {.f = -0.05}}),
    &((Keychord){1, {{MODKEY, XK_l}}, setmfact, {.f = +0.05}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_Return}}, zoom, {0}}),
    &((Keychord){1, {{MODKEY, XK_Tab}}, view, {0}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_q}}, killclient, {0}}),
    &((Keychord){1, {{MODKEY, XK_t}}, setlayout, {.v = &layouts[0]}}),
    &((Keychord){1, {{MODKEY, XK_f}}, setlayout, {.v = &layouts[1]}}),
    &((Keychord){1, {{MODKEY, XK_m}}, setlayout, {.v = &layouts[2]}}),
    &((Keychord){1, {{MODKEY, XK_space}}, setlayout, {0}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_space}}, togglefloating, {0}}),
    &((Keychord){1, {{MODKEY, XK_0}}, view, {.ui = ~0}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_0}}, tag, {.ui = ~0}}),
    &((Keychord){1, {{MODKEY, XK_comma}}, focusmon, {.i = -1}}),
    &((Keychord){1, {{MODKEY, XK_period}}, focusmon, {.i = +1}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_comma}}, tagmon, {.i = -1}}),
    &((Keychord){1, {{MODKEY | ShiftMask, XK_period}}, tagmon, {.i = +1}}),
    &((Keychord){1, {{MODKEY, XK_q}}, spawn, SHCMD("dm-session")}),

    /* PROGRAMS */
    &((Keychord){1, {{MODKEY | Mod1Mask, XK_b}}, spawn, SHCMD("$BROWSER")}),
    &((Keychord){1, {{MODKEY | Mod1Mask, XK_v}}, spawn, SHCMD("vscodium")}),
    &((Keychord){1, {{MODKEY | Mod1Mask, XK_x}}, spawn, SHCMD("firefox")}),
    &((Keychord){1, {{MODKEY | Mod1Mask, XK_c}}, spawn, SHCMD("gpick")}),
    &((Keychord){1, {{MODKEY | Mod1Mask, XK_t}}, spawn, SHCMD("thunar")}),
    &((Keychord){1, {{MODKEY | Mod1Mask, XK_o}}, spawn, SHCMD("obsidian")}),
    &((Keychord){1, {{MODKEY | ControlMask, XK_b}}, spawn, SHCMD("blueberry")}),
    &((Keychord){
        1, {{MODKEY | Mod1Mask, XK_i}}, spawn, SHCMD("timeshift-launcher")}),
    &((Keychord){1,
                 {{MODKEY | Mod1Mask, XK_p}},
                 spawn,
                 SHCMD("$TERMINAL -e pulsemixer")}),
    &((Keychord){
        1, {{MODKEY | Mod1Mask, XK_y}}, spawn, SHCMD("$TERMINAL -e btop")}),
    &((Keychord){
        1, {{MODKEY | Mod1Mask, XK_z}}, spawn, SHCMD("$TERMINAL -e htop")}),
    &((Keychord){
        1, {{MODKEY | Mod1Mask, XK_f}}, spawn, SHCMD("$TERMINAL -e lfub")}),

    /* DMENU */
    &((Keychord){1, {{MODKEY, XK_r}}, spawn, {.v = dmenucmd}}),
    &((Keychord){1, {{MODKEY, XK_b}}, spawn, SHCMD("dm-bluetooth")}),
    &((Keychord){1, {{MODKEY, XK_w}}, spawn, SHCMD("dm-wifi")}),
    &((Keychord){
        1, {{MODKEY, XK_e}}, spawn, SHCMD("rofi -show emoji -modi emoji")}),
    &((Keychord){1,
                 {{MODKEY, XK_c}},
                 spawn,
                 SHCMD("rofi -show calc -modi calc -no-show-match -no-sort")}),
    &((Keychord){1, {{MODKEY, XK_v}}, spawn, SHCMD("clipmenu")}),
    &((Keychord){
        1,
        {{MODKEY | ShiftMask, XK_t}},
        spawn,
        SHCMD("$TERMINAL -e sesh connect $(sesh list | dmenu -l 10)")}),

    /* SYSTEM */
    &((Keychord){1,
                 {{Mod1Mask, XK_F1}},
                 spawn,
                 SHCMD("pamixer --toggle-mute;"
                       "dunstify -r 3456 -t 2000 \"🔉 System "
                       "Volume $(pamixer --get-volume)%\"; "
                       "kill -$((34+10)) $(pidof dwmblocks)")}),
    &((Keychord){1,
                 {{Mod1Mask, XK_F2}},
                 spawn,
                 SHCMD("pamixer -d 2; dunstify -r 3456 -t 2000 \"🔉 System "
                       "Volume $(pamixer --get-volume)%\"; kill -$((34+10)) "
                       "$(pidof dwmblocks)")}),
    &((Keychord){1,
                 {{Mod1Mask, XK_F3}},
                 spawn,
                 SHCMD("pamixer -i 2; dunstify -r 3456 -t 2000 \"🔉 System "
                       "Volume $(pamixer --get-volume)%\"; kill -$((34+10)) "
                       "$(pidof dwmblocks)")}),
    &((Keychord){
        1,
        {{Mod1Mask, XK_F11}},
        spawn,
        SHCMD(
            "[ $(brightnessctl g) -gt 17 ] && brightnessctl set 2%-; "
            "dunstify -r 6789 -t 2000 \"💡 System Brightness $(brightnessctl | "
            "grep \"Current\" | awk -F'[()]' '{print $2}' | sed 's/%//g')%\";"
            "kill -$((34+11)) $(pidof dwmblocks)")}),
    &((Keychord){
        1,
        {{Mod1Mask, XK_F12}},
        spawn,
        SHCMD(
            "brightnessctl set +2%; "
            "dunstify -r 6789 -t 2000 \"💡 System Brightness $(brightnessctl | "
            "grep \"Current\" | awk -F'[()]' '{print $2}' | sed 's/%//g')%\";"
            "kill -$((34+11)) $(pidof dwmblocks)")}),
    &((Keychord){1,
                 {{Mod1Mask, XK_F5}},
                 spawn,
                 SHCMD("feh --recursive --bg-fill --randomize "
                       "$HOME/pictures/wallpapers")}),
    &((Keychord){1,
                 {{0, XK_Print}},
                 spawn,
                 SHCMD("disown & flameshot & flameshot screen -p "
                       "~/pictures/screenshots/ --clipboard")}),
    &((Keychord){1,
                 {{ShiftMask, XK_Print}},
                 spawn,
                 SHCMD("disown & flameshot & flameshot gui -p "
                       "~/pictures/screenshots/ --clipboard")}),

    /* SESSION */
    &((Keychord){1, {{MODKEY | Mod1Mask | ControlMask, XK_q}}, quit, {0}}),
    &((Keychord){1,
                 {{MODKEY | Mod1Mask | ControlMask, XK_p}},
                 spawn,
                 SHCMD("systemctl poweroff")}),
    &((Keychord){1,
                 {{MODKEY | Mod1Mask | ControlMask, XK_r}},
                 spawn,
                 SHCMD("systemctl reboot")}),
    &((Keychord){1,
                 {{MODKEY | Mod1Mask | ControlMask, XK_s}},
                 spawn,
                 SHCMD("systemctl suspend")}),
    &((Keychord){
        1, {{MODKEY | Mod1Mask | ControlMask, XK_l}}, spawn, SHCMD("slock")}),

    TAGKEYS(XK_1, 0) TAGKEYS(XK_2, 1) TAGKEYS(XK_3, 2) TAGKEYS(XK_4, 3)
        TAGKEYS(XK_5, 4) TAGKEYS(XK_6, 5) TAGKEYS(XK_7, 6) TAGKEYS(XK_8, 7)
            TAGKEYS(XK_9, 8)};

/* button definitions */
static const Button buttons[] = {
    /* click                event mask      button          function argument */
    {ClkLtSymbol, 0, Button1, setlayout, {0}},
    {ClkLtSymbol, 0, Button3, setlayout, {.v = &layouts[2]}},
    {ClkWinTitle, 0, Button2, zoom, {0}},
    {ClkStatusText, 0, Button2, spawn, {.v = termcmd}},
    {ClkClientWin, MODKEY, Button1, movemouse, {0}},
    {ClkClientWin, MODKEY, Button2, togglefloating, {0}},
    {ClkClientWin, MODKEY, Button3, resizemouse, {0}},
    {ClkTagBar, 0, Button1, view, {0}},
    {ClkTagBar, 0, Button3, toggleview, {0}},
    {ClkTagBar, MODKEY, Button1, tag, {0}},
    {ClkTagBar, MODKEY, Button3, toggletag, {0}},
};
